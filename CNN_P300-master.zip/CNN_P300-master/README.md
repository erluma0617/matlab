# CNN_P300
CNN_P300 is a matlab implemention of the paper "Convolutional Neural Networks for P300 Detection with Application to Brain-Computer Interfaces, by Hubert Cecotti and Axel Graser".<br>
Main function is CNN_P300.m which sets the training and test protocol;<br>
P300_CNNSetup initializes CNN;<br>
P300_CNN_Dave.m is the key function discribe the bp process in CNN;<br>
P300_CNNapplygrads.m calculates network output;<br>
P300_CNNff1.m calculates the weight delta;<br>
Note:ALL THIS FUNCTION ARE RUN IN P300 DATA PREPROCESSED FROM BCI COMPITITION III DATA II \<Subject_A_Test_120Hz.mat & Subject_A_Train_120Hz.mat\>.
http://pan.baidu.com/s/1qWBjYhu
